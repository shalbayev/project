<?php
		$name = filter_var(trim($_POST['name']),FILTER_SANITIZE_STRING);
		$lname = filter_var(trim($_POST['Lname']),FILTER_SANITIZE_STRING);
		$login = filter_var(trim($_POST['login']),FILTER_SANITIZE_STRING);
		$pass = filter_var(trim($_POST['password']),FILTER_SANITIZE_STRING);

		if(mb_strlen($login)<2||mb_strlen($login)>90){
			echo "Недопустимая длина логина";
			exit();
		}
		else if(mb_strlen($name)<2||mb_strlen($name)>50){
			echo "Недопустимая длина имени";
			exit();
		}
		else if(mb_strlen($lname)<2||mb_strlen($lname)>50){
			echo "Недопустимая длина фамилии";
			exit();
		}
		else if(mb_strlen($pass)<2||mb_strlen($pass)>15){
			echo "Недопустимая длина пароля(от 2 до 6 символов)";
			exit();
		}
		$pass = md5($pass."bwfhjwbj5547");
		$mysql = new mysqli('localhost','root','','register-bd');
		$mysql->query("INSERT INTO `users` (`login`,`pass`,`name`,`lname`) VALUES('$login','$pass','$name','$lname')");
		$mysql->close(); 
		header('Location: http://localhost/project/signup.html');
?>